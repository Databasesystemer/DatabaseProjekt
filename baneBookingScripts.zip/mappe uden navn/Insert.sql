
use BaneOversigt;


insert Hold values('Håndbold B', 'Niveau C', 20) ;
insert Hold values( null , 'Niveau C', 20) ;
insert Hold values( 'Håndbold C' , 'Niveau C', 20) ;


